<?php  

$servidor="localhost";
$basedatos="gimnasio";
$usuario="root";
$clave="";
$mysqli = new mysqli("$servidor","$usuario","$clave","$basedatos");
?>