-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 16-09-2019 a las 18:58:02
-- Versión del servidor: 5.7.21
-- Versión de PHP: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `gimnasio`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `cd_admin` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  `clave` text NOT NULL,
  PRIMARY KEY (`cd_admin`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `admin`
--

INSERT INTO `admin` (`cd_admin`, `usuario`, `clave`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asistencia`
--

DROP TABLE IF EXISTS `asistencia`;
CREATE TABLE IF NOT EXISTS `asistencia` (
  `cdasistencia` int(11) NOT NULL AUTO_INCREMENT,
  `cdcedula` int(11) NOT NULL,
  `dias` int(11) NOT NULL,
  `fechalimite` date NOT NULL,
  `estado` text NOT NULL,
  PRIMARY KEY (`cdasistencia`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `asistencia`
--

INSERT INTO `asistencia` (`cdasistencia`, `cdcedula`, `dias`, `fechalimite`, `estado`) VALUES
(1, 1065013729, 30, '2019-10-13', 'activo'),
(2, 1065013729, 30, '2019-10-13', 'activo'),
(3, 1065013729, 30, '2019-10-13', 'activo'),
(4, 123456789, 30, '2019-10-13', 'activo'),
(5, 1065010499, 30, '2019-10-13', 'activo'),
(6, 23254654, 2, '2019-10-13', 'activo'),
(7, 1065010499, 30, '2019-10-15', 'activo'),
(8, 1065010499, 1, '2019-10-16', 'activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `gastos`
--

DROP TABLE IF EXISTS `gastos`;
CREATE TABLE IF NOT EXISTS `gastos` (
  `cdgastos` int(11) NOT NULL AUTO_INCREMENT,
  `motivo` text NOT NULL,
  `valor` text NOT NULL,
  `anexo` text NOT NULL,
  `fecha` date NOT NULL,
  `creado` text NOT NULL,
  PRIMARY KEY (`cdgastos`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `gastos`
--

INSERT INTO `gastos` (`cdgastos`, `motivo`, `valor`, `anexo`, `fecha`, `creado`) VALUES
(1, 'Servicios', '40000\n                ', 'luz', '2019-09-13', 'admin'),
(2, 'Servicios', '200000\n                ', 'enerigia', '2019-09-13', 'admin'),
(3, 'Nomina', '300000\n                ', 'Pago al trabajador luis', '2019-09-13', 'admin'),
(4, 'Nomina', '300000\r\n                ', 'Pago al trabajador luis', '2019-09-17', 'admin');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `historicoasistencia`
--

DROP TABLE IF EXISTS `historicoasistencia`;
CREATE TABLE IF NOT EXISTS `historicoasistencia` (
  `cdhistoricoasistencia` int(11) NOT NULL AUTO_INCREMENT,
  `cdcedula` int(11) NOT NULL,
  `fecha` date NOT NULL,
  PRIMARY KEY (`cdhistoricoasistencia`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `historicoasistencia`
--

INSERT INTO `historicoasistencia` (`cdhistoricoasistencia`, `cdcedula`, `fecha`) VALUES
(1, 23254654, '2019-09-13');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `historicodepago`
--

DROP TABLE IF EXISTS `historicodepago`;
CREATE TABLE IF NOT EXISTS `historicodepago` (
  `cdvalor` int(11) NOT NULL AUTO_INCREMENT,
  `cliente` int(11) NOT NULL,
  `dias` int(11) NOT NULL,
  `valor` int(11) NOT NULL,
  `descuento` int(11) NOT NULL,
  `pagototal` int(11) NOT NULL,
  `metodosdepago` text NOT NULL,
  `anexo` text NOT NULL,
  `creado` text NOT NULL,
  `fecha` date NOT NULL,
  `fechalimite` date NOT NULL,
  PRIMARY KEY (`cdvalor`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `historicodepago`
--

INSERT INTO `historicodepago` (`cdvalor`, `cliente`, `dias`, `valor`, `descuento`, `pagototal`, `metodosdepago`, `anexo`, `creado`, `fecha`, `fechalimite`) VALUES
(1, 1065013729, 30, 60000, 10000, 50000, 'Efectivo', '', 'admin', '2019-09-13', '2019-10-13'),
(2, 123456789, 30, 60000, 2000, 58000, 'Tarjeta', '', 'admin', '2019-09-13', '2019-10-13'),
(3, 1065010499, 30, 60000, 10000, 50000, 'Tarjeta', 'pesas', 'admin', '2019-09-13', '2019-10-13'),
(4, 23254654, 3, 18000, 0, 18000, 'Tarjeta', 'pesas', 'admin', '2019-09-13', '2019-10-13'),
(5, 1065010499, 30, 60000, 0, 60000, 'Efectivo', 'pesas', 'admin', '2019-09-15', '2019-10-15'),
(6, 1065010499, 1, 7000, 5000, 2000, 'Efectivo', '', 'admin', '2019-09-16', '2019-10-16');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `terceros`
--

DROP TABLE IF EXISTS `terceros`;
CREATE TABLE IF NOT EXISTS `terceros` (
  `cedula` int(11) NOT NULL,
  `nombres` text NOT NULL,
  `direccion` text NOT NULL,
  `celular` varchar(10) NOT NULL,
  `sexo` varchar(1) NOT NULL,
  `fecha` date NOT NULL,
  PRIMARY KEY (`cedula`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `terceros`
--

INSERT INTO `terceros` (`cedula`, `nombres`, `direccion`, `celular`, `sexo`, `fecha`) VALUES
(1065013729, 'sebastian corcho', 'cll2 4a-19\n                ', '3106771171', 'H', '2019-09-13'),
(123456789, 'juan', 'cll 2 4a 3\n                ', '3205678907', 'H', '2019-09-13'),
(1065010499, 'jesus negrete', 'kgjerihtrj\n                ', '123456789', 'H', '2019-09-13'),
(23254654, 'svcdfgbt', 'htyjyuj\n                ', '466456757', 'H', '2019-09-13');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `valores`
--

DROP TABLE IF EXISTS `valores`;
CREATE TABLE IF NOT EXISTS `valores` (
  `cdvalores` int(11) NOT NULL AUTO_INCREMENT,
  `dias` int(11) NOT NULL,
  `valor` int(11) NOT NULL,
  PRIMARY KEY (`cdvalores`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `valores`
--

INSERT INTO `valores` (`cdvalores`, `dias`, `valor`) VALUES
(1, 1, 6000),
(2, 30, 60000);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
